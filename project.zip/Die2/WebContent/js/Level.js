/**
 * Level state.
 */
function Level() {
	Phaser.State.call(this);
}

/** @type Phaser.State */
var proto = Object.create(Phaser.State);
Level.prototype = proto;

Level.prototype.create = function() {
//	this.music = this.add.sound("music",1,false);
//	this.music.play();
	
	this.game.physics.startSystem(Phaser.Physics.ARCADE);
	this.game.physics.arcade.gravity.y = 1000; 
	
	this.cursor = this.input.keyboard.createCursorKeys();
	this.bg = this.game.add.sprite(0, 0, "bg1");
	this.bg.fixedToCamera = true;
	this.bg.width = this.game.width;
	this.bg.height = this.game.height;
	
	this.map = this.game.add.tilemap("map1");
	this.map.addTilesetImage('pmap1');
	this.maplayer = this.map.createLayer("Tile Layer 1");
	this.maplayer.resizeWorld();
	this.map.setCollisionBetween(0,100,true,this.maplayer);
	this.addKahang();

	

	/*this.girl5= this.addPlayer(200,700);

	this.girl5.play("walk");*/
	//this.game.camera.follow(this.player)
this.enemies = this.add.group();
	
	for(x in this.map.objects.object){
		 var obj = this.map.objects.object[x];
		 if(obj.type == "player"){
         console.log(this.player);            
         this.player = this.addPlayer(obj.x,obj.y);           
         this.player.play("idle"); 
         this.player.scale.set(0.3);
		 this.game.camera.follow(this.player, Phaser.Camera.FOLLOW_PLATFORMER);
		 }else if(obj.type=="enemy1"){
		 var c = this.addEnemy1(obj.x,obj.y);
		 this.enemies.add(c);
		// this.c.animations.add("walk").play(4,true);
		 }else if(obj.type=="enemy2"){
		 var c = this.addEnemy2(obj.x,obj.y);
		 this.enemies.add(c);
		 //this.c.animations.add("walk").play(4,true);
		 }else if(obj.type=="enemy3"){
		var c = this.addEnemy3(obj.x,obj.y);
		this.enemies.add(c);
		//this.c.animations.add("walk").play(4,true);
		}else if(obj.type=="item"){
			var c = this.addItem(obj.x,obj.y);
			this.enemies.add(c);
			}
		 } 
};
Level.prototype.addKahang = function() {
	boss1 = this.add.sprite(250, this.world.height - 250,
	"Kahang");
	boss1.anchor.set(0.5,1);
	boss1.animations.add("fly").play(2,true);
	
	//this.add.tween(boss1).to( { y: '-10000' }, 140000, Phaser.Easing.Linear.None, true);
	for( i=0;i<1000;i=i+100){
		j=-1;
		
		this.add.tween(boss1).to( {x : 1000}, 1000, "Quad.easeInOut", true, 0, Number.MAX_VALUE, true);
		
		}
	
};	

Level.prototype.moveKahang = function() {
	twn = this.add.tween(this.boss1);
	twn.to({
		y : 360
	}, 2000, "Linear", true, 0, Number.MAX_VALUE);

};

Level.prototype.update = function() {
	this.game.physics.arcade.collide(this.player,this.maplayer);
	this.game.physics.arcade.collide(this.enemies,this.maplayer);
	var cursor = this.input.keyboard.createCursorKeys();
    if( this.cursor.left.isDown ) {
        this.player.body.velocity.x = -100;
    	this.player.play("walk");
    	this.player.scale.x = -0.3;
      } 
    else if( this.cursor.right.isDown ) {
        this.player.body.velocity.x = 100;
    	this.player.play("walk");
    	this.player.scale.x = 0.3;
      } 
    else {
        this.player.body.velocity.x = 0;
        this.player.play("idle");
      }
 
  if( this.cursor.up.isDown  && this.player.body.velocity.y == 0 ) {
	  	this.player.body.velocity.y = -1000;
    	this.player.body.velocity.x = 0.3;
    	this.player.play("jump");
    	 if( this.cursor.left.isDown ) {
 	        this.player.body.velocity.x = -100;
 	    	this.player.scale.x = -0.3;
 	      } 
 	    else{
 	        this.player.body.velocity.x = 100;
 	    	this.player.scale.x = 0.3;
 	      } 
  } 
	
	

	};

Level.prototype.addPlayer = function(x,y) {
	var g = this.add.sprite(x,y,"chara");
	g.animations.add("attack",gframes("attack",11),12,true);
	g.animations.add("idle",gframes("idle",11),12,true);
	g.animations.add("jump",gframes("jump",11),12,true);
	g.animations.add("walk",gframes("walk",11),12,true);
	
	g.anchor.set(0.5,1);
	g.smoothed = false;
	this.game.physics.enable(g);
	g.body.collideWorldBounds = true;
	g.body.drag.setTo(500, 0);
	g.smoothed = false;
	//g.body.setSize(40,80,10,15);
	return g;
	
	};
	Level.prototype.addEnemy1 = function(x,y){
		c = this.add.sprite(x, y, "e1");
		c.anchor.set(0.5,1);
		c.animations.add("walk").play(4,true);
		 this.game.physics.enable(c);
		 c.body.collideWorldBounds = true;
		return c;

	};

Level.prototype.addEnemy2 = function(x,y){
		c = this.add.sprite(x, y, "e2");
		c.animations.add("walk").play(4,true);
		c.anchor.set(0.5,1);
		 this.game.physics.enable(c);
		 c.body.collideWorldBounds = true;
		return c;

	};
Level.prototype.addEnemy3 = function(x,y){
		c = this.add.sprite(x, y, "e3");
		c.animations.add("walk").play(4,true);
		c.anchor.set(0.5,1);
		 this.game.physics.enable(c);
		 c.body.collideWorldBounds = true;
	
		return c;

	};
Level.prototype.addItem = function(x,y){
	c = this.add.sprite(x, y, "water");
	c.animations.add("walk").play(2,true);
	c.anchor.set(0.5,1);
	c.scale.set(3);
	 this.game.physics.enable(c);
	 c.body.collideWorldBounds = true;

	return c;

	};	

function gframes(key,n){
	var f=[ ];
	for(var i=0;i<=n;i++){
	 var kf=key+"_"+(("00" + i).slice (-3));
	 f.push(kf);
	}
	return f;
	}


Level.prototype.quitGame = function() {
	this.game.state.start("Menu");
};